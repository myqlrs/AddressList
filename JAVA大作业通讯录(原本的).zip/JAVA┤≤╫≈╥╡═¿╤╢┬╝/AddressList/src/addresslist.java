import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.sql.*;
class addresslist extends JFrame implements ActionListener{//ֻʹ����addresslistһ�Σ�ֻ����������һ��ʵ�����󣬶�������ע�������ť��
	private static final long serialVersionUID = 1L;
	private static String call;
	public static String id;
	JMenuBar jmb;//�˵���
	JMenu jm1,jm2,jm3,jm4,jmquit,jmbackup;//����ʽ�˵�
    JMenuItem jmi1,jmi2,jmi3,jmi4,jmi5,jmi6,jmi7,jmi8,jmi9,jmiquitProgram,jmireLogin,jmibackup;//�˵���
    JCheckBox jcb1,jcb2,jcb3;//��ѡ��
    JRadioButton jrb1,jrb2,jrb3,jrbman,jrbwoman;//��ѡ��ť
    JTextField jt1,jt2,jt3,jt4,jtContactName,jtDeleteGroup,jtDeleteContact,jtuser,jtgroup,jtname,jtbirthday,jthomeAddress,jtpostcode,jttelephone,jthandset,jtEmail,jtQQ,jtMSN,jtcompanyAddress,jtcompanyPhone,jtgroupname,jtgroupname1,jtsex;
    JTable table;
    Object a[][];
    Object name[]={"����","�Ա�","�ֻ�����","����","QQ","��ַ","��λ","����"};			
    JScrollPane sp =null;//��������
    JButton jb,jb1,jbAdd,jbCancel,jbAddGroup,jbCancelGroup,jbYes,jbNo,jbsubmit,jbnull,jbDeleteGroup,jbDeleteContact,jbSearchName;//����ʽ��ť
    String s1,s2,s3;
    JLabel jlgroup,jlContactName,jlname,jluser,jlsex,jlhomeAddress,jlpostcode,jltelephone,jlhandset,jlEmail,jlQQ,jlcompanyAddress,jlcompanyPhone,jlgroupname;
    JLabel jloldPassword,jlnewPassword,jlconfirmPassword;
    JPasswordField jpoldPassword,jpnewPassword,jpconfirmPassword;
    int count=0,cgroupid;
    String backup[][];
    int n=0,j=0;
    Container mainContainer;//��������
    public addresslist(String s){
    	mainContainer=getContentPane();
    	setTitle(s);
    	call=s;
    	setBounds(370,100,800,600);
 	    setVisible(true);
 	    setResizable(false);
 	    mainContainer.setLayout(null);
 	    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
 	    jmb=new JMenuBar();//�˵���
 	    jm1=new JMenu("��ѯ ");
 	    jm1.setFont(new Font("����",Font.BOLD,20));
	    jmb.add(jm1);
	    jmi1=new JMenuItem("ģ����ѯ"); //�˵���
	    jmi1.setFont(new Font("������",Font.PLAIN,15));
	    jmi2=new JMenuItem("��ȷ��ѯ");
	    jmi2.setFont(new Font("������",Font.PLAIN,15));
	    jmi1.addActionListener(this);
	    jmi2.addActionListener(this);
	    jm1.add(jmi1);
	    jm1.addSeparator();
	    jm1.add(jmi2);
	    
 	    jm2=new JMenu("���� ");
 	    jm2.setFont(new Font("����",Font.BOLD,20));
	    jmb.add(jm2);
	    jm2.addActionListener(this);
	    jmi4=new JMenuItem("������ϵ��");
	    jmi4.setFont(new Font("������",Font.PLAIN,15)); 
	    jmi4.addActionListener(this);
	    jm2.add(jmi4);
        	    
 	    jm3=new JMenu("�޸� ");
 	    jm3.setFont(new Font("����",Font.BOLD,20));
	    jmb.add(jm3);
	    jm3.addActionListener(this);
	    //jmi5=new JMenuItem("�޸ķ�����Ϣ"); 
	    //jmi5.setFont(new Font("������",Font.PLAIN,15));
	    jmi6=new JMenuItem("�޸���ϵ����Ϣ");
	    jmi6.setFont(new Font("������",Font.PLAIN,15));
	    jmi7=new JMenuItem("�޸�����  ");
	    jmi7.setFont(new Font("������",Font.PLAIN,15));
	    //jmi5.addActionListener(this);
	    jmi6.addActionListener(this);
	    jmi7.addActionListener(this);
	    //jm3.add(jmi5);
	    //jm3.addSeparator();
	    jm3.add(jmi6);
	    jm3.addSeparator();
	    jm3.add(jmi7);
	    	    
 	    jm4=new JMenu("ɾ�� ");
 	    jm4.setFont(new Font("����",Font.BOLD,20));
	    jmb.add(jm4);
	    jmi8=new JMenuItem("ɾ������"); 
	    jmi8.setFont(new Font("������",Font.PLAIN,15));
	    jmi9=new JMenuItem("ɾ����ϵ��");
	    jmi9.setFont(new Font("������",Font.PLAIN,15));
	    jmi8.addActionListener(this);
	    jmi9.addActionListener(this);
	    jm4.add(jmi8);
	    jm4.addSeparator();
	    jm4.add(jmi9);

	    jmbackup=new JMenu("���� ");
	    jmbackup.setFont(new Font("����",Font.BOLD,20));
	    jmb.add(jmbackup);
	    jmibackup=new JMenuItem("����������ϵ����Ϣ"); 
	    jmibackup.setFont(new Font("������",Font.PLAIN,15));
	    jmibackup.addActionListener(this);
	    jmbackup.add(jmibackup);
	    
	    jmquit=new JMenu("�˳�");
	    jmquit.setFont(new Font("����",Font.BOLD,20));
	    jmb.add(jmquit);
	    jmiquitProgram=new JMenuItem("�˳�����"); 
	    jmiquitProgram.setFont(new Font("������",Font.PLAIN,15));
	    jmireLogin=new JMenuItem("���µ�¼"); 
	    jmireLogin.setFont(new Font("������",Font.PLAIN,15));
	    jmiquitProgram.addActionListener(this);
	    jmireLogin.addActionListener(this);
	    jmquit.add(jmiquitProgram);
	    jmquit.addSeparator();
	    jmquit.add(jmireLogin);    
    	setJMenuBar(jmb);
    	validate(); 
    	
    }
    public void clear(){	//������б༭���е�����		
    	jtname.setText("");
    	jtsex.setText("");
    	jthandset.setText("");
    	jtEmail.setText("");
    	jtQQ.setText("");
    	jtcompanyAddress.setText("");
    	jtcompanyPhone.setText("");
    	jtgroupname.setText("");
	}//Clear()����
    public void actionPerformed(ActionEvent e){
    	if(e.getSource()==jmi1){
    		mainContainer.removeAll();//�Ƴ���ǰ�����ڵ���������
            JLabel jlb=new JLabel("��ѯ��ϵ����Ϣ");
            mainContainer.add(jlb);//����ǩ������ӵ�ǰ����
            jlb.setFont(new Font("����",Font.BOLD,22));
            jlb.setBounds(300,10,180,30);//���ø�ʵ���Ŀռ��С
    		jcb1=new JCheckBox("��������ѯ");
    		jcb1.setFont(new Font("΢���ź�",Font.PLAIN,15));
    		mainContainer.add(jcb1);
    		
    		jcb1.setBounds(110,50,100,30);
    		JLabel jl1=new JLabel("����������");
    		jl1.setFont(new Font("������",Font.BOLD,16));
    		mainContainer.add(jl1);
    		jl1.setBounds(10,90,100,30);
    		jt1=new JTextField(10);
    		mainContainer.add(jt1);
    	    jt1.setFont(new Font("����",Font.PLAIN,15));
    	    jt1.setBounds(110,90,100,30);
    		
    		jcb2=new JCheckBox("�������ѯ");
    		jcb2.setFont(new Font("΢���ź�",Font.PLAIN,15));
    		mainContainer.add(jcb2);
    		
    		jcb2.setBounds(320,50,100,30);
    		JLabel jl2=new JLabel("��������");
    		jl2.setFont(new Font("������",Font.BOLD,16));
    		mainContainer.add(jl2);
    		jl2.setBounds(240, 90, 80, 30);
    		jt2=new JTextField(10);
    		mainContainer.add(jt2);
    	    jt2.setFont(new Font("����",Font.PLAIN,15));
    	    jt2.setBounds(320,90,100,30);
    		
    		jcb3=new JCheckBox("���ֻ������ѯ");
    		jcb3.setFont(new Font("΢���ź�",Font.PLAIN,15));
    		mainContainer.add(jcb3);
    		
    		jcb3.setBounds(530,50,150,30);
    		JLabel jl3=new JLabel("�ֻ�����");
    		jl3.setFont(new Font("������",Font.BOLD,16));
    		mainContainer.add(jl3);
    		jl3.setBounds(440, 90, 80, 30);
    		jt3=new JTextField(10);
    		mainContainer.add(jt3);
    	    jt3.setFont(new Font("����",Font.PLAIN,15));
    	    jt3.setBounds(530,90,150,30);
    	    jb=new JButton("��ѯ");
    	    mainContainer.add(jb);
    	    jb.setFont(new Font("������",Font.BOLD,22));
    		jb.addActionListener(this);
    		jb.setBounds(280,135,180,30);
    		Object name[]={"����","�Ա�","�ֻ�����","����","QQ","��ַ","��λ","����"};			
    	    a=new Object[20][15];
		    table=new JTable(a,name);
		    table.setAutoResizeMode(0);
			sp = new JScrollPane(table);
			sp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
			sp.setVerticalScrollBarPolicy( JScrollPane.VERTICAL_SCROLLBAR_ALWAYS); 
			sp.setBounds(5,180,780,360); 
			mainContainer.add(sp);  
			mainContainer.repaint();//����repaint()���������½�����ʾ
    	}
    	if(e.getSource()==jb){
    		id=accessDB.getnowID(call);
    		String cid=id;
            try{
            	// ����JDBC-ODBC����������
                Class.forName("com.hxtt.sql.access.AccessDriver");
                // ͨ������Դ�����ݿ⽨��������
                Connection c=DriverManager.getConnection("jdbc:Access:////D:/eclipse-workspace/AddressList/addresslistDB.accdb");
                Statement s=c.createStatement(); // ����SQL������          
       	        StringBuffer str=new StringBuffer("select strName,strSex,strPhone,strMailbox,strQQ,strAddress,strUnit,strSorted from linkman where linkman.ID='" + cid + "' ");
       	        if(jcb1.isSelected()==true){
       	        	str.append("and strName like '%"+jt1.getText()+"%'");
       	        }
       	        if(jcb2.isSelected()==true){
       	        	str.append("and strSorted  like '%"+jt2.getText()+"%'");
       	        }
       	        if(jcb3.isSelected()==true){
       	        	str.append("and strPhone like '%"+jt3.getText()+"%'");
       	        }
       	        ResultSet rs=s.executeQuery(str.toString());
       	        while(rs.next()){
			      count++;
			    }
			    Object[][] a=new Object[count][8];
				rs=s.executeQuery(str.toString());
				count=0;
				while(rs.next()){
				    a[count][0]=rs.getString(1);
					a[count][1]=rs.getString(2);
					a[count][2]=rs.getString(3);
					a[count][3]=rs.getString(4);
					a[count][4]=rs.getString(5);
					a[count][5]=rs.getString(6);
					a[count][6]=rs.getString(7);
					a[count][7]=rs.getString(8);
					count++;
				}				
				Object name[]={"����","�Ա�","�ֻ�����","����","QQ","��ַ","��λ","����"};			
				getContentPane().remove(sp);
				table=new JTable(a,name);
				table.setAutoResizeMode(0);
				sp = new JScrollPane(table);
				sp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
				sp.setVerticalScrollBarPolicy( JScrollPane.VERTICAL_SCROLLBAR_ALWAYS); 
				sp.setBounds(5,180,780,360);  
				add(sp);
				rs.close();
				s.close();
       	        c.close();
       	    }
            catch (Exception e1)
            {
                System.err.println("�쳣: " + e1.getMessage( ));
            } // try-catch�ṹ����
    		
    	}
    	if(e.getSource()==jmi2){
    		mainContainer.removeAll();
    		ButtonGroup bgp=new ButtonGroup();
    		JLabel jlb=new JLabel("��ѯ��ϵ����Ϣ");
    		mainContainer.add(jlb);
            jlb.setFont(new Font("����",Font.BOLD,22));
            jlb.setBounds(300,10,180,30);
    		jrb1=new JRadioButton("��������ѯ");
    		jrb1.setFont(new Font("΢���ź�",Font.PLAIN,15));
    		jrb1.setBounds(110,50,100,30);
    		bgp.add(jrb1);
    		mainContainer.add(jrb1);	
    		
    		jrb2=new JRadioButton("���ֻ��Ų�ѯ");
    		jrb2.setFont(new Font("΢���ź�",Font.PLAIN,15));
    		jrb2.setBounds(320,50,150,30);
    		bgp.add(jrb2);
    		mainContainer.add(jrb2);
    		
    		jrb3=new JRadioButton("��QQ�Ų�ѯ");
    		jrb3.setFont(new Font("΢���ź�",Font.PLAIN,15));
    		jrb3.setBounds(530,50,150,30);
    		bgp.add(jrb3);
    		mainContainer.add(jrb3);
    		
    		jt4=new JTextField();
    		mainContainer.add(jt4);
    	    jt4.setFont(new Font("����",Font.PLAIN,15));
    	    jt4.setBounds(250,110,150,30);
    	    
    	    jb1=new JButton("����");
    	    jb1.setFont(new Font("����",Font.BOLD,15));
    	    mainContainer.add(jb1);
    	    jb1.addActionListener(this);
    	    jb1.setBounds(420,110,100,30);
    	    Object name[]={"����","�Ա�","�ֻ�����","����","QQ","��ַ","��λ","����"};			
    	    a=new Object[20][15];
		    table=new JTable(a,name);
		    table.setAutoResizeMode(0);
			sp = new JScrollPane(table);
			sp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
			sp.setVerticalScrollBarPolicy( JScrollPane.VERTICAL_SCROLLBAR_ALWAYS); 
			sp.setBounds(5,180,780,360); 
			mainContainer.add(sp);
			mainContainer.repaint();
    	}
    	if(e.getSource()==jb1){
    		id=accessDB.getnowID(call);
    		String cid=id;
            try{
            	// ����JDBC-ODBC����������
                Class.forName("com.hxtt.sql.access.AccessDriver");
                // ͨ������Դ�����ݿ⽨��������
                Connection c=DriverManager.getConnection("jdbc:Access:////D:/eclipse-workspace/AddressList/addresslistDB.accdb");
                Statement s=c.createStatement(); // ����SQL������          
       	        StringBuffer str1=new StringBuffer("select strName,strSex,strPhone,strMailbox,strQQ,strAddress,strUnit,strSorted from linkman where linkman.ID='" + cid + "' ");       
       	        if(jrb1.isSelected()==true){
       	        	str1.append("and strName='"+jt4.getText()+"'");
       	        }
       	        else if(jrb2.isSelected()==true){
       	        	str1.append("and strPhone='"+jt4.getText()+"'");
       	        }
       	        else if(jrb3.isSelected()==true){
       	        	str1.append("and strQQ='"+jt4.getText()+"'");
       	        }
       	        ResultSet rs=s.executeQuery(str1.toString());
       	        while(rs.next()){
			      count++;
			    }
			    Object[][] a=new Object[count][15];
				rs=s.executeQuery(str1.toString());
				count=0;
				while(rs.next()){
				    a[count][0]=rs.getString(1);
					a[count][1]=rs.getString(2);
					a[count][2]=rs.getString(3);
					a[count][3]=rs.getString(4);
					a[count][4]=rs.getString(5);
					a[count][5]=rs.getString(6);
					a[count][6]=rs.getString(7);
					a[count][7]=rs.getString(8);
					count++;
				}				
				Object name[]={"����","�Ա�","�ֻ�����","����","QQ","��ַ","��λ","����"};			
			    getContentPane().remove(sp);
				table=new JTable(a,name);
				table.setAutoResizeMode(0);
				sp = new JScrollPane(table);
				sp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
				sp.setVerticalScrollBarPolicy( JScrollPane.VERTICAL_SCROLLBAR_ALWAYS); 
				sp.setBounds(5,180,780,360);  
				add(sp);
				rs.close();
				s.close();
       	        c.close();
       	    }catch (Exception e1)
            {
                System.err.println("�쳣: " + e1.getMessage( ));
            } // try-catch�ṹ����
    	}   
    	if(e.getSource()==jbCancelGroup){
    		mainContainer.removeAll();
    		mainContainer.repaint();
    	}
    	if(e.getSource()==jmi4){
    		mainContainer.removeAll();   		 		
    		jlname=new JLabel("��  ��");
    		jlname.setFont(new Font("����",Font.BOLD,14));
    		jlname.setSize(80,30);
    		jlname.setLocation(185, 85);
    		mainContainer.add(jlname);
    		jtname=new JTextField();
    		jtname.setFont(new Font("����",Font.BOLD,14));
    		jtname.setSize(200,25);
    		jtname.setLocation(250, 87);
    		mainContainer.add(jtname);
    		
    		jlsex=new JLabel("��  ��");
    		jlsex.setFont(new Font("����",Font.BOLD,14));
    		jlsex.setSize(80,30);
    		jlsex.setLocation(185, 130);
    		mainContainer.add(jlsex);
    		jtsex = new JTextField();
    		jtsex.setFont(new Font("����",Font.BOLD,14));
    		jtsex.setSize(200,25);
    		jtsex.setLocation(250, 132);
    		mainContainer.add(jtsex);
    		
    		jlhandset=new JLabel("��  ��");
    		jlhandset.setFont(new Font("����",Font.BOLD,14));
    		jlhandset.setSize(80,30);
    		jlhandset.setLocation(185, 175);
    		mainContainer.add(jlhandset);
    		jthandset=new JTextField();
    		jthandset.setFont(new Font("����",Font.BOLD,14));
    		jthandset.setSize(200,25);
    		jthandset.setLocation(250, 177);
    		mainContainer.add(jthandset);
    		
    		jlEmail=new JLabel("��  ��");
    		jlEmail.setFont(new Font("����",Font.BOLD,14));
    		jlEmail.setSize(80,30);
    		jlEmail.setLocation(185, 220);
    		mainContainer.add(jlEmail);
    		jtEmail=new JTextField();
    		jtEmail.setFont(new Font("����",Font.BOLD,14));
    		jtEmail.setSize(200,25);
    		jtEmail.setLocation(250, 222);
    		mainContainer.add(jtEmail);
    		
    		jlQQ=new JLabel("Q   Q");
    		jlQQ.setFont(new Font("����",Font.BOLD,14));
    		jlQQ.setSize(80,30);
    		jlQQ.setLocation(185, 265);
    		mainContainer.add(jlQQ);
    		jtQQ=new JTextField();
    		jtQQ.setFont(new Font("����",Font.BOLD,14));
    		jtQQ.setSize(200,25);
    		jtQQ.setLocation(250, 267);
    		mainContainer.add(jtQQ); 		
    		jlcompanyAddress=new JLabel("��  ַ");
    		jlcompanyAddress.setFont(new Font("����",Font.BOLD,14));
    		jlcompanyAddress.setSize(80,30);
    		jlcompanyAddress.setLocation(185, 310);
    		mainContainer.add(jlcompanyAddress);
    		jtcompanyAddress=new JTextField();
    		jtcompanyAddress.setFont(new Font("����",Font.BOLD,14));
    		jtcompanyAddress.setSize(200,25);
    		jtcompanyAddress.setLocation(250, 312);
    		mainContainer.add(jtcompanyAddress);
    		
    		jlcompanyPhone=new JLabel("��  λ");
    		jlcompanyPhone.setFont(new Font("����",Font.BOLD,14));
    		jlcompanyPhone.setSize(80,30);
    		jlcompanyPhone.setLocation(185, 355);
    		mainContainer.add(jlcompanyPhone);
    		jtcompanyPhone=new JTextField();
    		jtcompanyPhone.setFont(new Font("����",Font.BOLD,14));
    		jtcompanyPhone.setSize(200,25);
    		jtcompanyPhone.setLocation(250, 357);
    		mainContainer.add(jtcompanyPhone);
    		
    		jlgroupname=new JLabel("��  ��");
    		jlgroupname.setFont(new Font("����",Font.BOLD,14));
    		jlgroupname.setSize(80,30);
    		jlgroupname.setLocation(185, 400);
    		mainContainer.add(jlgroupname);
    		jtgroupname=new JTextField();
    		jtgroupname.setFont(new Font("����",Font.BOLD,14));
    		jtgroupname.setSize(200,25);
    		jtgroupname.setLocation(250, 402);
    		mainContainer.add(jtgroupname);
    				
    		jbAdd=new JButton("����");
    		jbAdd.setFont(new Font("΢���ź�",Font.BOLD,16));
    		jbAdd.setSize(100,30);
    		jbAdd.setLocation(185, 495);
    		jbAdd.addActionListener(this);
    		mainContainer.add(jbAdd);
    		jbCancel=new JButton("ȡ��");
    		jbCancel.setFont(new Font("΢���ź�",Font.BOLD,16));
    		jbCancel.setSize(100,30);
    		jbCancel.setLocation(350,495);
    		jbCancel.addActionListener(this);
    		mainContainer.add(jbCancel);
    		
    		mainContainer.repaint();
    	}
    	if(e.getSource()==jbAdd){//����
    		id=accessDB.getnowID(call);
    		String cid=id;
    	    String cName=jtname.getText();
    	    String cSex=jtsex.getText();
    		String cHandset=jthandset.getText();
    		String cEmail=jtEmail.getText();
    		String cQQ=jtQQ.getText();
    		String cCompanyAddress=jtcompanyAddress.getText();
    		String cCompanyPhone=jtcompanyPhone.getText();
    		String cGroupname=jtgroupname.getText();
    		try {
    			// ����JDBC-ODBC����������
                Class.forName("com.hxtt.sql.access.AccessDriver");
                // ͨ������Դ�����ݿ⽨��������
                Connection c=DriverManager.getConnection("jdbc:Access:////D:/eclipse-workspace/AddressList/addresslistDB.accdb");
                Statement sta=c.createStatement(); // ����SQL������
                String sql = "insert into linkman(ID,strName,strSex,strPhone,strMailbox,strQQ,strAddress,strUnit,strSorted) values(?,?,?,?,?,?,?,?,?)";
       	        if(cName.equals("")){
    		        JOptionPane.showMessageDialog(this,"��������Ϊ�գ�","��ʾ",JOptionPane.INFORMATION_MESSAGE);
    			    jtname.requestFocus();
    		    }
    		    else if(sta.executeQuery("select * from linkman where linkman.ID='" + cid + "' and strName='"+cName+"'").next()==true){
    			    JOptionPane.showMessageDialog(this,"�����Ѵ��ڣ�","��ʾ",JOptionPane.INFORMATION_MESSAGE);
                    jtname.requestFocus();
    		    }
    		    else{
    		    	PreparedStatement psInsert=c.prepareStatement(sql);// ����Ԥ����SQL���
                    psInsert.setString(1, cid);
                    psInsert.setString(2, cName);
                    psInsert.setString(3, cSex);
                    psInsert.setString(4, cHandset);
                    psInsert.setString(5, cEmail);
                    psInsert.setString(6, cQQ);
                    psInsert.setString(7, cCompanyAddress);
                    psInsert.setString(8, cCompanyPhone);
                    psInsert.setString(9, cGroupname);
                    psInsert.executeUpdate( );
                    clear();
                    JOptionPane.showMessageDialog(this,"���ӳɹ���","��ʾ",JOptionPane.INFORMATION_MESSAGE);
    		    }
				sta.close();
    	        c.close();
    		}
    		catch (Exception e1)
            {
                System.err.println("�쳣: " + e1.getMessage( ));
            } // try-catch�ṹ����
    	}
    	if(e.getSource()==jbCancel){
    		mainContainer.removeAll();
    		mainContainer.repaint();
    	}  	
        if(e.getSource()==jmi6){
        	mainContainer.removeAll();	
        	jlContactName=new JLabel("������Ҫ�޸ĵ���ϵ������");
        	jlContactName.setFont(new Font("����",Font.PLAIN,20));
        	jlContactName.setBounds(130,30,250,30);
        	mainContainer.add(jlContactName);
        	jtContactName=new JTextField(20);
        	jtContactName.setFont(new Font("����",Font.PLAIN,18));
        	jtContactName.setBounds(380,30,100,30);
        	mainContainer.add(jtContactName);
        	jbSearchName=new JButton("����");
        	jbSearchName.setFont(new Font("����",Font.PLAIN,20));
        	jbSearchName.setBounds(490,30,80,30);
        	jbSearchName.addActionListener(this);
        	mainContainer.add(jbSearchName);
        	
        	mainContainer.repaint();
    	}
        if(e.getSource()==jbSearchName){
        	id=accessDB.getnowID(call);
    		String cid=id;
            try{
            	// ����JDBC-ODBC����������
                Class.forName("com.hxtt.sql.access.AccessDriver");
                // ͨ������Դ�����ݿ⽨��������
                Connection c=DriverManager.getConnection("jdbc:Access:////D:/eclipse-workspace/AddressList/addresslistDB.accdb");
                Statement sta=c.createStatement(); // ����SQL������ 
                ResultSet rs = null;
       	        if(jtContactName.getText().equals("")==true){
           		    JOptionPane.showMessageDialog(this,"��ϵ����������Ϊ�գ�","��ʾ",JOptionPane.INFORMATION_MESSAGE);
           		    jtContactName.requestFocus();
           	    }
       	        else if(sta.executeQuery("select strName,strSex,strPhone,strMailbox,strQQ,strAddress,strUnit,strSorted from linkman where linkman.ID='" + cid + "' and strName='"+jtContactName.getText()+"'").next()==false){
       	        	JOptionPane.showMessageDialog(this,"����ϵ�˲����ڣ�","��ʾ",JOptionPane.INFORMATION_MESSAGE);
       	        	jtContactName.requestFocus();     	        	
       	        }
       	        else{
       	            rs=sta.executeQuery("select strName,strSex,strPhone,strMailbox,strQQ,strAddress,strUnit,strSorted from linkman where linkman.ID='" + cid + "' and strName=='"+jtContactName.getText()+"'");
       	        	while(rs.next()){
       	        		search.strName=rs.getString(1);
       	        		search.strSex=rs.getString(2);
       	        		search.strPhone=rs.getString(3);
       	        		search.strMailbox=rs.getString(4);
       	        		search.strQQ=rs.getString(5);
       	        		search.strAddress=rs.getString(6);
       	        		search.strUnit=rs.getString(7);
       	        		search.strSorted=rs.getString(8);
       	        		
       	        	}
       	        	new Mondifylinkman(call);
       	        	this.dispose();
       	        }
       	        rs.close();
				sta.close();
    	        c.close();
       	    }
            catch (Exception e1)
            {
                System.err.println("�쳣: " + e1.getMessage( ));
            } // try-catch�ṹ���� 
        }
        if(e.getSource()==jmi7){
        	mainContainer.removeAll();	
        	jluser=new JLabel("�û���");
            jluser.setFont(new Font("����",Font.BOLD,20));
            jluser.setBounds(250, 30, 80, 30);
            mainContainer.add(jluser);
            jtuser=new JTextField(20);
            jtuser.setText(call);
            jtuser.setFont(new Font("����",Font.PLAIN,18));
            jtuser.setBounds(350, 30, 150, 30);
            mainContainer.add(jtuser);
            
            jloldPassword=new JLabel("������");
            jloldPassword.setFont(new Font("����",Font.BOLD,20));
            jloldPassword.setBounds(250, 80, 80, 30);
            mainContainer.add(jloldPassword);
            jpoldPassword=new JPasswordField(20);
            jpoldPassword.setFont(new Font("����",Font.PLAIN,18));
            jpoldPassword.setBounds(350, 80, 150, 30);
            mainContainer.add(jpoldPassword);
            
            jlnewPassword=new JLabel("������");
            jlnewPassword.setFont(new Font("����",Font.BOLD,20));
            jlnewPassword.setBounds(250, 130, 80, 30);
            mainContainer.add(jlnewPassword);
            jpnewPassword=new JPasswordField(20);
            jpnewPassword.setFont(new Font("����",Font.PLAIN,18));
            jpnewPassword.setBounds(350, 130, 150, 30);
            mainContainer.add(jpnewPassword);
            
            jlconfirmPassword=new JLabel("ȷ������");
            jlconfirmPassword.setFont(new Font("����",Font.BOLD,20));
            jlconfirmPassword.setBounds(250, 180, 100, 30);
            mainContainer.add(jlconfirmPassword);
            jpconfirmPassword=new JPasswordField(20);
            jpconfirmPassword.setFont(new Font("����",Font.PLAIN,18));
            jpconfirmPassword.setBounds(350, 180, 150, 30);
            mainContainer.add(jpconfirmPassword);
            
            jbsubmit=new JButton("�ύ");
            jbsubmit.setFont(new Font("����",Font.BOLD,20));
            jbsubmit.setBounds(280,240,80,30);
            jbsubmit.addActionListener(this);
            mainContainer.add(jbsubmit);
            jbnull=new JButton("����");
            jbnull.setFont(new Font("����",Font.BOLD,20));
            jbnull.setBounds(390,240,80,30);
            jbnull.addActionListener(this);
            mainContainer.add(jbnull);
            
        	mainContainer.repaint();
        }
        if(e.getSource()==jbsubmit){
        	String nowpassWord=accessDB.getnowpassWord(call);
    		String cName=call;
            try{
            	// ����JDBC-ODBC����������
                //Class.forName("com.hxtt.sql.access.AccessDriver");
                // ͨ������Դ�����ݿ⽨��������
                Connection c=DriverManager.getConnection("jdbc:Access:////D:/eclipse-workspace/AddressList/addresslistDB.accdb");
                Statement s=c.createStatement(); // ����SQL������                	        
            	if(new String(jpoldPassword.getPassword()).equals(nowpassWord)==false) {
            		JOptionPane.showMessageDialog(this,"����Ҫ�޸ĵľ���������޸�ʧ�ܣ�","��ʾ",JOptionPane.INFORMATION_MESSAGE);
              		jpnewPassword.requestFocus();
            	}
                else if(new String(jpnewPassword.getPassword()).equals("")==true){
            		JOptionPane.showMessageDialog(this,"�����벻��Ϊ�գ�","��ʾ",JOptionPane.INFORMATION_MESSAGE);
              		jpnewPassword.requestFocus();
              	}
            	else if(new String(jpnewPassword.getPassword()).equals(new String(jpconfirmPassword.getPassword()))==false){
            		JOptionPane.showMessageDialog(this,"�������ȷ�����벻һ�£�","��ʾ",JOptionPane.INFORMATION_MESSAGE);
              		jpnewPassword.requestFocus();
              	}
                else{
            	    int n=JOptionPane.showConfirmDialog(this,"ȷ��Ҫ�޸��û�������","ȷ�϶Ի���",JOptionPane.YES_NO_OPTION);	
            	    if(n==JOptionPane.YES_OPTION){
            	        s.executeUpdate("update user set passWord='"+new String(jpconfirmPassword.getPassword())+"' where userName='" + cName + "'");
            	        JOptionPane.showMessageDialog(this,"�޸ĳɹ�","��ʾ",JOptionPane.INFORMATION_MESSAGE);
            	   }
            	   else{
            		   jbDeleteGroup.requestFocus();
            	   }
                }
            	s.close();
    	        c.close();
    	     }
             catch (Exception e1){
                 System.err.println("�쳣: " + e1.getMessage( ));
             } // try-catch�ṹ����       	
        }
        if(e.getSource()==jbnull){
        	jpoldPassword.setText("");
        	jpnewPassword.setText("");
        	jpconfirmPassword.setText("");
        }
        if(e.getSource()==jmi8){
        	mainContainer.removeAll();
        	jlgroup=new JLabel("������");
    		jlgroup.setFont(new Font("����",Font.PLAIN,20));
    		jlgroup.setBounds(230,50,100,30);
    		mainContainer.add(jlgroup);
    		jtDeleteGroup=new JTextField(20);
    		jtDeleteGroup.setFont(new Font("����",Font.PLAIN,18));
    		jtDeleteGroup.setBounds(320,50,120,30);
    		mainContainer.add(jtDeleteGroup);
    		jbDeleteGroup=new JButton("ɾ��");
    		jbDeleteGroup.setFont(new Font("����",Font.PLAIN,20));
    		jbDeleteGroup.setBounds(450,50,80,30);
    		jbDeleteGroup.addActionListener(this);
    		mainContainer.add(jbDeleteGroup);
    		mainContainer.repaint();
        }
        if(e.getSource()==jbDeleteGroup){
        	id=accessDB.getnowID(call);
    		String cid=id;
            try{
            	// ����JDBC-ODBC����������
                //Class.forName("com.hxtt.sql.access.AccessDriver");
                // ͨ������Դ�����ݿ⽨��������
                Connection c=DriverManager.getConnection("jdbc:Access:////D:/eclipse-workspace/AddressList/addresslistDB.accdb");
                Statement s=c.createStatement(); // ����SQL������                	        
            	if(jtDeleteGroup.getText().equals("")){
            		JOptionPane.showMessageDialog(this,"����������Ϊ�գ�","��ʾ",JOptionPane.INFORMATION_MESSAGE);
            	}
            	else if(s.executeQuery("select strName,strSex,strPhone,strMailbox,strQQ,strAddress,strUnit,strSorted from linkman where linkman.ID='" + cid + "' and strSorted=='"+jtDeleteGroup.getText()+"'").next()==false){
    	            JOptionPane.showMessageDialog(this,"���鲻���ڣ�","��ʾ",JOptionPane.INFORMATION_MESSAGE);
            	}
                else{
            	    int n=JOptionPane.showConfirmDialog(this,"ȷ��Ҫɾ���÷�������������ϵ����","ȷ�϶Ի���",JOptionPane.YES_NO_OPTION);	
            	    if(n==JOptionPane.YES_OPTION){
            	        s.executeUpdate("delete from linkman where linkman.ID='" + cid + "' and strSorted='"+jtDeleteGroup.getText()+"'");
            	        JOptionPane.showMessageDialog(this,"ɾ���ɹ�","��ʾ",JOptionPane.INFORMATION_MESSAGE);
            	   }
            	   else{
            		   jtDeleteGroup.requestFocus();
            	   }
                }
            	s.close();
    	        c.close();
    	     }
             catch (Exception e1){
                 System.err.println("�쳣: " + e1.getMessage( ));
             } // try-catch�ṹ����
        }
        if(e.getSource()==jmi9){
        	mainContainer.removeAll();
        	jlgroup=new JLabel("��ϵ������");
    		jlgroup.setFont(new Font("������",Font.BOLD,20));
    		jlgroup.setBounds(200,50,120,30);
    		mainContainer.add(jlgroup);
    		jtDeleteContact=new JTextField(20);
    		jtDeleteContact.setFont(new Font("����",Font.PLAIN,18));
    		jtDeleteContact.setBounds(320,50,120,30);
    		mainContainer.add(jtDeleteContact);
    		jbDeleteContact=new JButton("ɾ��");
    		jbDeleteContact.setFont(new Font("����",Font.PLAIN,20));
    		jbDeleteContact.setBounds(450,50,80,30);
    		jbDeleteContact.addActionListener(this);
    		mainContainer.add(jbDeleteContact);
    		mainContainer.repaint();
        }
        if(e.getSource()==jbDeleteContact){
        	id=accessDB.getnowID(call);
    		String cid=id;
            try{
            	// ����JDBC-ODBC����������
                //Class.forName("com.hxtt.sql.access.AccessDriver");
                // ͨ������Դ�����ݿ⽨��������
                Connection c=DriverManager.getConnection("jdbc:Access:////D:/eclipse-workspace/AddressList/addresslistDB.accdb");
                Statement s=c.createStatement(); // ����SQL������               	        
            	if(jtDeleteContact.getText().equals("")){
            		JOptionPane.showMessageDialog(this,"��ϵ����������Ϊ�գ�","��ʾ",JOptionPane.INFORMATION_MESSAGE);
            	}
            	else if(s.executeQuery("select strName,strSex,strPhone,strMailbox,strQQ,strAddress,strUnit,strSorted from linkman where linkman.ID='" + cid + "' and strName=='"+jtDeleteContact.getText()+"'").next()==false){
    	            JOptionPane.showMessageDialog(this,"��ϵ�˲����ڣ�","��ʾ",JOptionPane.INFORMATION_MESSAGE);
            	}
                else{
            	    int n=JOptionPane.showConfirmDialog(this,"ȷ��Ҫɾ������ϵ����","ȷ�϶Ի���",JOptionPane.YES_NO_OPTION);	
            	    if(n==JOptionPane.YES_OPTION){
            	        s.executeUpdate("delete from linkman where linkman.ID='" + cid + "' and strName='"+jtDeleteContact.getText()+"'");
            	        JOptionPane.showMessageDialog(this,"ɾ���ɹ�","��ʾ",JOptionPane.INFORMATION_MESSAGE);
            	   }
            	   else{
            		   jtDeleteContact.requestFocus();
            	   }
                }
            	s.close();
    	        c.close();
    	     }
             catch (Exception e1){
                 System.err.println("�쳣: " + e1.getMessage( ));
             } // try-catch�ṹ����
        } 
        if(e.getSource()==jmiquitProgram){
        	System.exit(0);
        }
        if(e.getSource()==jmireLogin){
        	new login();
        	this.dispose();
        }
        if(e.getSource()==jmibackup){
        	id=accessDB.getnowID(call);
    		String cid=id;
            try{
            	// ����JDBC-ODBC����������
                Class.forName("com.hxtt.sql.access.AccessDriver");
                // ͨ������Դ�����ݿ⽨��������
                Connection c=DriverManager.getConnection("jdbc:Access:////D:/eclipse-workspace/AddressList/addresslistDB.accdb");
                Statement sta=c.createStatement(); // ����SQL������               
                ResultSet rs=sta.executeQuery("select strName,strSex,strPhone,strMailbox,strQQ,strAddress,strUnit,strSorted from linkman where linkman.ID='" + cid + "'");
            	while(rs.next()){
            		n++;
            	}
            	backup=new String[n][8];
            	n=0;
            	rs=sta.executeQuery("select strName,strSex,strPhone,strMailbox,strQQ,strAddress,strUnit,strSorted from linkman where linkman.ID='" + cid + "'");
            	while(rs.next()){
            		backup[n][0]=rs.getString(1);
            		backup[n][1]=rs.getString(2);
            		backup[n][2]=rs.getString(3);
            		backup[n][3]=rs.getString(4);
            		backup[n][4]=rs.getString(5);
            		backup[n][5]=rs.getString(6);
            		backup[n][6]=rs.getString(7);
            		backup[n][7]=rs.getString(8);
            		n++;
            	}
            	try{
            		JFileChooser chooser2=new JFileChooser();
            	  	int state=chooser2.showSaveDialog(null);
            	  	if(state==JFileChooser.APPROVE_OPTION){
            	  	    File f2=new File(chooser2.getSelectedFile().getAbsolutePath()+".txt");
            	  	 	FileWriter fw=new FileWriter(f2);
            	  	 	BufferedWriter fin = new BufferedWriter(fw);
					    for(j=0;j<n;j++){
					       for(int i=0;i<8;i++){
					           fin.write(backup[j][i]+"  ");
					       }
					       fin.newLine();
					    }
					    fin.flush();
					    fin.close();
            	  	}
				}
            	catch (Exception e1)
                {
	                System.err.println("�쳣: " + e1.getMessage( ));
	            } // try-catch�ṹ����
            	rs.close();
            	sta.close();
    	        c.close();
    	    }
            catch (Exception e1)
            {
                System.err.println("�쳣: " + e1.getMessage( ));
            } // try-catch�ṹ����
        }
    }
}
class search{
	public static String strName;
	public static String strSex;
	public static String strPhone;
	public static String strMailbox;
	public static String strQQ;
	public static String strAddress;
	public static String strUnit;
	public static String strSorted;
}





