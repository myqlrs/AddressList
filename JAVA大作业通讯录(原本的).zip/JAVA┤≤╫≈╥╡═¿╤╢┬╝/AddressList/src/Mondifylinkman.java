import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
class Mondifylinkman extends JFrame implements ActionListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static String call;
	public static String id;
	JLabel jlname,jlsex,jlhandset,jlEmail,jlQQ,jlcompanyAddress,jlcompanyPhone,jlgroupname;
	JTextField jtname,jtsex,jthandset,jtEmail,jtQQ,jtcompanyAddress,jtcompanyPhone,jtgroupname;
	JButton jbModify,jbCancel; 
	public Mondifylinkman(String s){
		setTitle(s);
		call=s;
		setBounds(370,100,800,600);
 	    setVisible(true);
 	    setResizable(false);
 	    setLayout(null);
 	    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
 	    jlname = new JLabel("��  ��");
		jlname.setFont(new Font("����",Font.BOLD,14));
		jlname.setSize(80,30);
		jlname.setLocation(185, 85);
		add(jlname);
		jtname = new JTextField(search.strName);
		jtname.setFont(new Font("����",Font.BOLD,14));
		jtname.setSize(200,25);
		jtname.setLocation(250, 87);
		add(jtname);
		
		jlsex = new JLabel("��  ��");
		jlsex.setFont(new Font("����",Font.BOLD,14));
		jlsex.setSize(80,30);
		jlsex.setLocation(185, 130);
		add(jlsex);
	    jtsex = new JTextField(search.strSex);
		jtsex.setFont(new Font("����",Font.BOLD,14));
		jtsex.setSize(200,25);
		jtsex.setLocation(250, 132);
		add(jtsex);
		
		jlhandset = new JLabel("��  ��");
		jlhandset.setFont(new Font("����",Font.BOLD,14));
		jlhandset.setSize(80,30);
		jlhandset.setLocation(185, 175);
		add(jlhandset);
		jthandset = new JTextField(search.strPhone);
		jthandset.setFont(new Font("����",Font.BOLD,14));
		jthandset.setSize(200,25);
		jthandset.setLocation(250, 177);
		add(jthandset);
		
		jlEmail = new JLabel("��  ��");
		jlEmail.setFont(new Font("����",Font.BOLD,14));
		jlEmail.setSize(80,30);
		jlEmail.setLocation(185, 220);
		add(jlEmail);
		jtEmail = new JTextField(search.strMailbox);
		jtEmail.setFont(new Font("����",Font.BOLD,14));
		jtEmail.setSize(200,25);
		jtEmail.setLocation(250, 222);
		add(jtEmail);
		
		jlQQ = new JLabel("Q   Q");
		jlQQ.setFont(new Font("����",Font.BOLD,14));
		jlQQ.setSize(80,30);
		jlQQ.setLocation(185, 265);
		add(jlQQ);
		jtQQ = new JTextField(search.strQQ);
		jtQQ.setFont(new Font("����",Font.BOLD,14));
		jtQQ.setSize(200,25);
		jtQQ.setLocation(250, 267);
		add(jtQQ); 		
		jlcompanyAddress = new JLabel("��  ַ");
		jlcompanyAddress.setFont(new Font("����",Font.BOLD,14));
		jlcompanyAddress.setSize(80,30);
		jlcompanyAddress.setLocation(185, 310);
		add(jlcompanyAddress);
		jtcompanyAddress = new JTextField(search.strAddress);
		jtcompanyAddress.setFont(new Font("����",Font.BOLD,14));
		jtcompanyAddress.setSize(200,25);
		jtcompanyAddress.setLocation(250, 312);
		add(jtcompanyAddress);
		
		jlcompanyPhone = new JLabel("��  λ");
		jlcompanyPhone.setFont(new Font("����",Font.BOLD,14));
		jlcompanyPhone.setSize(80,30);
		jlcompanyPhone.setLocation(185, 355);
		add(jlcompanyPhone);
		jtcompanyPhone = new JTextField(search.strUnit);
		jtcompanyPhone.setFont(new Font("����",Font.BOLD,14));
		jtcompanyPhone.setSize(200,25);
		jtcompanyPhone.setLocation(250, 357);
		add(jtcompanyPhone);
		
		jlgroupname = new JLabel("��  ��");
		jlgroupname.setFont(new Font("����",Font.BOLD,14));
		jlgroupname.setSize(80,30);
		jlgroupname.setLocation(185, 400);
		add(jlgroupname);
		jtgroupname = new JTextField(search.strSorted);
		jtgroupname.setFont(new Font("����",Font.BOLD,14));
		jtgroupname.setSize(200,25);
		jtgroupname.setLocation(250, 402);
		add(jtgroupname);
				
		jbModify = new JButton("�޸�");
		jbModify.setFont(new Font("΢���ź�",Font.BOLD,16));
		jbModify.setSize(100,30);
		jbModify.setLocation(185, 495);
		jbModify.addActionListener(this);
		add(jbModify);
		jbCancel = new JButton("ȡ��");
		jbCancel.setFont(new Font("΢���ź�",Font.BOLD,16));
		jbCancel.setSize(100,30);
		jbCancel.setLocation(350,495);
		jbCancel.addActionListener(this);
		add(jbCancel);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==jbCancel){
			new addresslist(call);
			this.dispose();
		}
		else if(e.getSource()==jbModify){
			id=accessDB.getnowID(call);
    		String cid=id;
    		String nowName=search.strName;
    	    String cName=jtname.getText();
    	    String cSex=jtsex.getText();
    		String cHandset=jthandset.getText();
    		String cEmail=jtEmail.getText();
    		String cQQ=jtQQ.getText();
    		String cCompanyAddress=jtcompanyAddress.getText();
    		String cCompanyPhone=jtcompanyPhone.getText();
    		String cGroupname=jtgroupname.getText();
    		try {
    			// ����JDBC-ODBC����������
                Class.forName("com.hxtt.sql.access.AccessDriver");
                // ͨ������Դ�����ݿ⽨��������
                Connection c=DriverManager.getConnection("jdbc:Access:////D:/eclipse-workspace/AddressList/addresslistDB.accdb");
                Statement sta=c.createStatement(); // ����SQL������
                sta.executeUpdate("update linkman set strName='"+cName+"',strSex='"+cSex+"',strPhone='"+cHandset+"',strMailbox='"+cEmail+"',strQQ='"+cQQ+"',strAddress='"+cCompanyAddress+"',strUnit='"+cCompanyPhone+"',strSorted='"+cGroupname+"' where linkman.ID='" + cid + "' and strName='"+nowName+"'");
       		    JOptionPane.showMessageDialog(this,"�޸ĳɹ���","��ʾ",JOptionPane.INFORMATION_MESSAGE);
       		    new addresslist(call);
          	    this.dispose();
          	    sta.close();
   	            c.close();
    		}
    		catch (Exception e1)
            {
                System.err.println("�쳣: " + e1.getMessage( ));
            } // try-catch�ṹ����
		}
	}
}
