import java.awt.Container;
import java.awt.Dimension;

import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class login extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField jbf= null;   
	private JTextField jpf= null;
	private JButton  btnInt=null;
	private JButton  btnSin=null;
	JFrame jf;
	Container c;
	public void clear(){  
		jbf.setText("");                    //清空用户名文本框  
		jpf.setText("");                    //清空密码文本框  
		jbf.requestFocus();                 //用户名文本框得到输入焦点  
	} 
	public login() {
		jf=new JFrame();     //实例化JFrame对象
		jf.setTitle("系统登录窗体");       //设置窗体的一些格式
		jf.setSize(400, 300);           //设置窗体的大小
        jf.setLocationRelativeTo(null); //设置窗口居中 
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//设置窗体的关闭方式    
		jf.setVisible(true);//设置窗体可视化
		//c=jf.getContentPane();//将窗体转化为容器
        //接下来就可以在容器中添加组件或者设置布局管理器
        //初始化面板
        JPanel j= new JPanel();
		j.setLayout(null);
		//在面板添加按钮
		JLabel  l1 = new JLabel();
		l1.setBounds(new Rectangle(70, 25, 60, 25));
        l1.setText("用户名：");      
        JLabel  l2 = new JLabel();
        l2.setBounds(new Rectangle(70, 75, 60, 25));
		l2.setText("密码：");   
        j.add(l1, null);
        j.add(getjbf(), null);
        j.add(l2, null);
        j.add(getjpf(), null);
        j.add(getbtnInt(), null);
        j.add(getbtnSin(), null);
        jf.add(j);
        //将面板添加到容器
        //c.add(j);	    
	}
	private JTextField getjbf() {
		if (jbf == null) {
			jbf = new JTextField();
			jbf.setBounds(new Rectangle(150, 25, 120, 25));
		}
		return jbf;
	}
	private JTextField getjpf() {
		if (jpf == null) {
			jpf = new JTextField();
			jpf.setBounds(new Rectangle(150, 75, 120, 25));
		}
		return jpf;
	}
	private JButton getbtnInt(){
	  if (btnInt== null) {
	    // 登录按钮设置和监听事件  
	    btnInt=new JButton();//事件源
	    btnInt.setText("登录");
	    btnInt.setSize(new Dimension(60, 25));
	    btnInt.setLocation(new Point(100, 120));      //匿名内部类实现处理命令式按钮动作事件
	    btnInt.addActionListener(new ActionListener() { //事件监听 
           public void actionPerformed(ActionEvent e) { //事件
             // 登录按钮响应事件  
             String user = jbf.getText().trim();            // 获得用户名  
             String pwd =  jpf.getText().trim();            // 获得密码  
             if (user.equals("")) {  
                 JOptionPane.showMessageDialog(null, "用户名不能为空");  
             } 
             else if (pwd.equals("")) {  
                 JOptionPane.showMessageDialog(null, "密码不能为空");  
             }
             else {
                if (accessDB.check(user, pwd)) {  
                   JOptionPane.showMessageDialog(null, "登入成功");
                   new addresslist(user);
                   jf.dispose();               
                } 
                else {  
                   JOptionPane.showMessageDialog(null, "对不起用户名或密码错误");  
                   clear();  
                }
             }
          }
        });
	  }
	  return btnInt;
	}
	
	private JButton getbtnSin(){
	   if (btnSin== null) {
         //注册按钮设置和响应事件  
	     btnSin=new JButton();
		 btnSin.setText("注册");
		 btnSin.setSize(new Dimension(60, 25));
		 btnSin.setLocation(new Point(200, 120));
         btnSin.addActionListener(new ActionListener() {  
           public void actionPerformed(ActionEvent e) {  
             // 注册按钮响应事件  
             String user = jbf.getText().trim();   // 获得用户名  
             String pwd =  jpf.getText().trim();   // 获得密码  
             String sql = "";                      // 声明sql语句  
             if (user.equals("")) {  
                 JOptionPane.showMessageDialog(null, "用户名不能为空");  
             } 
             else if (pwd.equals("")) {  
                 JOptionPane.showMessageDialog(null, "密码不能为空");  
             } 
             else {  
                 sql = "select * from user where userName='" + user + "'";  
                 if (accessDB.isExist(sql)) {// 用户名已经存在  
                     JOptionPane.showMessageDialog(null, "对不起，用户名已存在！！！");  
                     clear();// 清空输入文本框  
                 } 
                 else {  
                	 sql = "insert into user(userName,passWord) values(?, ?)";  
                     if (accessDB.insertUser(sql,user,pwd)) {// 注册成功  
                         JOptionPane.showMessageDialog(null,  "恭喜您！！！注册成功，请登陆");  
                         clear();  
                     }  
                 }  
             }  
          }  
        });
	   }
      return btnSin;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				login user = new login();
				user.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				user.setVisible(true);
			}
		});
	}
		
}
